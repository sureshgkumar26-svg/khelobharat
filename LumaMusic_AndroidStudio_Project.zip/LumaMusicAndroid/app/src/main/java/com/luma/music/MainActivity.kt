package com.luma.music

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var list: LinearLayout
    private lateinit var nowPlaying: TextView
    private lateinit var status: TextView
    private var tracks: List<Track> = emptyList()
    private var filtered: List<Track> = emptyList()
    private var currentIndex = -1
    private var shuffle = false
    private var repeat = 0 // 0 off, 1 all, 2 one
    private var serviceBound = false
    private var playback: PlaybackService? = null
    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            playback = (binder as PlaybackService.LocalBinder).getService()
            serviceBound = true
        }
        override fun onServiceDisconnected(name: ComponentName?) { serviceBound = false; playback = null }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 15, 23)
        window.navigationBarColor = Color.rgb(16, 15, 23)
        buildShell()
        requestMusicPermission()
        val intent = Intent(this, PlaybackService::class.java)
        startService(intent)
        bindService(intent, connection, Context.BIND_AUTO_CREATE)
    }

    private fun buildShell() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(20), dp(18), dp(12)); setBackgroundColor(Color.rgb(16,15,23)) }
        val header = TextView(this).apply { text = "LUMA  ♪"; textSize = 25f; setTextColor(Color.rgb(211,195,255)); typeface = android.graphics.Typeface.DEFAULT_BOLD }
        root.addView(header)
        root.addView(TextView(this).apply { text = "YOUR MUSIC, YOUR MOOD"; textSize = 10f; letterSpacing = .18f; setTextColor(Color.rgb(157,151,177)); setPadding(0, dp(3), 0, dp(14)) })
        val search = EditText(this).apply { hint = "Search your library"; setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); setPadding(dp(12), 0, dp(12), 0); setBackgroundColor(Color.rgb(37,34,49)) }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(46)))
        search.addTextChangedListener(SimpleTextWatcher { query ->
            filtered = tracks.filter { it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true) }
            renderTracks()
        })
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, dp(8)) }
        val scan = button("Scan again") { scanMusic() }
        val shuffleButton = button("Shuffle: off") { shuffle = !shuffle; (it as Button).text = "Shuffle: ${if (shuffle) "on" else "off"}" }
        val repeatButton = button("Repeat: off") { repeat = (repeat + 1) % 3; (it as Button).text = "Repeat: ${listOf("off", "all", "one")[repeat]}" }
        controls.addView(scan); controls.addView(shuffleButton); controls.addView(repeatButton)
        root.addView(controls)
        status = TextView(this).apply { text = "Allow audio access to find songs stored on your phone."; setTextColor(Color.rgb(173,166,194)); textSize = 12f; setPadding(0, dp(4), 0, dp(8)) }
        root.addView(status)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val player = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(8)); setBackgroundColor(Color.rgb(37,34,49)) }
        nowPlaying = TextView(this).apply { text = "Nothing playing yet"; textSize = 15f; setTextColor(Color.WHITE); typeface = android.graphics.Typeface.DEFAULT_BOLD }
        player.addView(nowPlaying)
        val actions = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("Previous") { playRelative(-1) })
        actions.addView(button("Play / Pause") { if (serviceBound) playback?.toggle() })
        actions.addView(button("Next") { playRelative(1) })
        player.addView(actions)
        root.addView(player)
        setContentView(root)
    }

    private fun requestMusicPermission() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) scanMusic()
        else requestPermissions(arrayOf(permission), 100)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) scanMusic()
        else status.text = "Music access is needed to scan songs on this device. You can allow it in Android Settings."
    }

    private fun scanMusic() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) { requestMusicPermission(); return }
        val found = mutableListOf<Track>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION)
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 1000"
        try {
            contentResolver.query(collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { cursor: Cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    found.add(Track(id, cursor.getString(titleCol) ?: "Unknown title", cursor.getString(artistCol) ?: "Unknown artist", cursor.getString(albumCol) ?: "Unknown album", cursor.getLong(durationCol), ContentUris.withAppendedId(collection, id)))
                }
            }
        } catch (e: Exception) { status.text = "Could not scan music: ${e.localizedMessage ?: "unknown error"}"; return }
        tracks = found
        filtered = found
        status.text = "${found.size} local songs found · works offline"
        renderTracks()
    }

    private fun renderTracks() {
        list.removeAllViews()
        if (filtered.isEmpty()) {
            list.addView(TextView(this).apply { text = if (tracks.isEmpty()) "No local songs found yet. Download audio files to your phone, then tap Scan again." else "No songs match your search."; setTextColor(Color.LTGRAY); setPadding(0, dp(20), 0, dp(20)) })
            return
        }
        filtered.forEach { track ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(10), dp(6), dp(10)); setBackgroundColor(Color.rgb(25,23,35)) }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(TextView(this).apply { text = track.title; textSize = 15f; setTextColor(Color.WHITE); typeface = android.graphics.Typeface.DEFAULT_BOLD; maxLines = 1 })
            info.addView(TextView(this).apply { text = "${track.artist}  ·  ${formatDuration(track.durationMs)}"; textSize = 12f; setTextColor(Color.rgb(170,163,190)); maxLines = 1 })
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(button("▶") { currentIndex = tracks.indexOf(track); startTrack(track) })
            row.setOnClickListener { currentIndex = tracks.indexOf(track); startTrack(track) }
            val params = LinearLayout.LayoutParams(-1, -2); params.bottomMargin = dp(5); list.addView(row, params)
        }
    }

    private fun startTrack(track: Track) {
        nowPlaying.text = "${track.title}\n${track.artist}"
        val intent = Intent(this, PlaybackService::class.java).apply { action = PlaybackService.ACTION_PLAY; data = track.uri; putExtra(PlaybackService.EXTRA_TITLE, track.title); putExtra(PlaybackService.EXTRA_ARTIST, track.artist) }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
    }

    private fun playRelative(direction: Int) {
        if (tracks.isEmpty()) return
        currentIndex = if (shuffle && direction > 0) (tracks.indices).filter { it != currentIndex }.randomOrNull() ?: 0 else (currentIndex + direction + tracks.size) % tracks.size
        startTrack(tracks[currentIndex])
    }

    private fun button(label: String, click: (View) -> Unit): Button = Button(this).apply {
        text = label; textSize = 10f; isAllCaps = false; setTextColor(Color.rgb(224,215,255)); setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(53,47,70))); setOnClickListener(click)
        minWidth = 0; minimumWidth = 0; setPadding(dp(7), 0, dp(7), 0)
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun formatDuration(ms: Long): String = String.format(Locale.getDefault(), "%d:%02d", ms / 60000, (ms / 1000) % 60)

    override fun onDestroy() {
        if (serviceBound) unbindService(connection)
        super.onDestroy()
    }
}
