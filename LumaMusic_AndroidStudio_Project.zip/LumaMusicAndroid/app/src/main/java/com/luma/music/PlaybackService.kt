package com.luma.music

import android.app.*
import android.content.*
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.net.Uri

class PlaybackService : Service() {
    private val binder = LocalBinder()
    private var player: MediaPlayer? = null
    private var currentTitle = "Luma Music"
    private var currentArtist = "Ready to play"

    inner class LocalBinder : Binder() { fun getService(): PlaybackService = this@PlaybackService }
    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIFICATION_ID, notification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> intent.data?.let { uri ->
                currentTitle = intent.getStringExtra(EXTRA_TITLE) ?: "Unknown title"
                currentArtist = intent.getStringExtra(EXTRA_ARTIST) ?: "Unknown artist"
                playUri(uri)
            }
            ACTION_TOGGLE -> toggle()
            ACTION_STOP -> { player?.stop(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
        }
        return START_STICKY
    }

    fun toggle() {
        val p = player ?: return
        if (p.isPlaying) p.pause() else p.start()
        updateNotification()
    }

    private fun playUri(uri: Uri) {
        player?.release()
        player = null
        try {
            player = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                setWakeMode(this@PlaybackService, PowerManager.PARTIAL_WAKE_LOCK)
                setDataSource(this@PlaybackService, uri)
                setOnPreparedListener { it.start(); updateNotification() }
                setOnCompletionListener { updateNotification() }
                setOnErrorListener { _, _, _ -> updateNotification(); true }
                prepareAsync()
            }
            updateNotification()
        } catch (_: Exception) { player?.release(); player = null; updateNotification() }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Luma playback", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        val toggleIntent = Intent(this, PlaybackService::class.java).setAction(ACTION_TOGGLE)
        val togglePending = PendingIntent.getService(this, 1, toggleIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setContentTitle(currentTitle).setContentText(currentArtist)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_pause, if (player?.isPlaying == true) "Pause" else "Play", togglePending).build())
            .setOngoing(player?.isPlaying == true).build()
    }
    private fun updateNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, notification())
    }
    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }

    companion object {
        const val ACTION_PLAY = "com.luma.music.PLAY"
        const val ACTION_TOGGLE = "com.luma.music.TOGGLE"
        const val ACTION_STOP = "com.luma.music.STOP"
        const val EXTRA_TITLE = "title"
        const val EXTRA_ARTIST = "artist"
        private const val CHANNEL_ID = "luma_playback"
        private const val NOTIFICATION_ID = 1107
    }
}
