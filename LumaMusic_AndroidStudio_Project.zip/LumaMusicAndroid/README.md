# Luma Music — Android Studio starter project

This is a native Kotlin Android project starter for Luma Music. It automatically scans the device's shared audio library using Android MediaStore after the user grants audio permission, lists searchable tracks, starts local playback, and provides a basic foreground playback notification.

## Open and build
1. Install Android Studio on a computer (the Android Studio desktop app is required to build this project).
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `LumaMusicAndroid` folder.
4. Allow Gradle sync and install the Android SDK 35 if prompted.
5. Connect an Android phone with USB debugging enabled, or use an emulator, then press **Run**.
6. To make an APK, use **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

## What's in this starter
- Native Android app structure (Kotlin)
- Automatic scan of local music using MediaStore
- Search by title, artist, or album
- Basic local playback and a foreground notification with play/pause
- Shuffle toggle UI and repeat mode UI scaffolding
- Dark Luma theme

## Not yet implemented
This is a starter, not a finished release. The shuffle/repeat controls are currently UI scaffolding rather than a complete queue engine. Album art extraction/custom cover persistence, lyrics, real EQ and reverb/lo-fi audio effects, sleep timer/fade-out, full media-session/lock-screen controls, listening analytics/database, Google sign-in, phone OTP, and cloud backup are not implemented yet. Authentication needs provider configuration and a secure backend; never store OTPs or passwords directly in the app. Device testing and signing are required before public release.

## Requirements
- Android Studio with JDK 17 support
- Android SDK 35
- Gradle sync requires internet access to download the Android Gradle Plugin and Kotlin plugin; playback itself uses local files and can work offline.
